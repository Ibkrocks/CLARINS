/** Mocked Service for ScrollToService */
export class ScrollToServiceMock {
  scrollTo() { }
}
