/*
 * Public API Surface of ngx-scroll-to
 */

export * from './lib/scroll-to-config.interface';
export * from './lib/scroll-to-easing.interface';
export * from './lib/scroll-to.directive';
export * from './lib/scroll-to.module';
export * from './lib/scroll-to.service';
